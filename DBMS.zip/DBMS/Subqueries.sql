USE AdventureWorks2017
GO


-- Select all products having same list price as 'Mountain Pump'
SELECT  Name, ListPrice
FROM Production.Product
WHERE ListPrice = 
    (SELECT ListPrice
     FROM Production.Product
     WHERE Name = 'Mountain Pump' );
GO

-- Get Name of all customers who have purchased from TerritoryID 5
SELECT BusinessEntityID, Name
FROM Sales.Store
WHERE BusinessEntityID  IN
    (SELECT CustomerID
     FROM Sales.Customer
     WHERE TerritoryID = 5);
	 GO

-- REplace subquery with join

SELECT s.BusinessEntityID, s.Name
FROM Sales.Store s JOIN Sales.Customer c
ON s.BusinessEntityID = c.CustomerID
WHERE c.TerritoryID = 5
-- Subquery using ANY

SELECT Name, ListPrice
FROM Production.Product
WHERE ListPrice >= ALL
    (SELECT MAX (ListPrice)
     FROM Production.Product
     GROUP BY ProductSubcategoryID)
ORDER BY 2
GO


-- find the names of employees who are also sales persons

SELECT LastName, FirstName
FROM Person.Person
WHERE BusinessEntityID IN
    (SELECT BusinessEntityID
     FROM HumanResources.Employee
     WHERE BusinessEntityID IN
        (
		SELECT BusinessEntityID
         FROM Sales.SalesPerson)
    )
	GO

-- using join

SELECT LastName, FirstName
FROM Person.Person p INNER JOIN HumanResources.Employee e
ON (p.BusinessEntityID = e.BusinessEntityID)
INNER JOIN Sales.SalesPerson sp
ON (e.BusinessEntityID = sp.BusinessEntityID)


GO
-- Corelated Subquery
-- Query to find names of all salesperson who have recieved a bonus of 5000
SELECT DISTINCT c.LastName, c.FirstName, e.BusinessEntityID 
FROM Person.Person AS c JOIN HumanResources.Employee AS e
ON e.BusinessEntityID = c.BusinessEntityID 
WHERE 5000.00 IN
    (SELECT Bonus
    FROM Sales.SalesPerson sp
    WHERE e.BusinessEntityID = sp.BusinessEntityID) 

GO


-- Subquery in Select
SELECT Ord.SalesOrderID, Ord.OrderDate,
    (SELECT MAX(OrdDet.UnitPrice)
     FROM Sales.SalesOrderDetail OrdDet
     WHERE Ord.SalesOrderID = OrdDet.SalesOrderID) AS MaxUnitPrice
FROM Sales.SalesOrderHeader AS Ord;
GO


-- Exists
-- finds the names of all products that are in the Wheels subcategory:

SELECT Name
FROM Production.Product
WHERE EXISTS
    (SELECT * 
     FROM Production.ProductSubcategory
     WHERE ProductSubcategoryID = 
            Production.Product.ProductSubcategoryID
        AND Name = 'Wheels')

GO