use AdventureWorks2017
Go

CREATE OR ALTER PROCEDURE Proc_sales
AS
DECLARE
 @var money
BEGIN
   Select @var = max(UnitPrice)
   from sales.SalesOrderDetail
   
   SELECT sh.salesorderid, sh.OrderDate, sh.CustomerID, sh.PurchaseOrderNumber,
   sd.UnitPrice, sd.OrderQty, sd.ProductID
   FROM sales.SalesOrderDetail sd JOIN sales.SalesOrderHeader sh
   ON (sd.Salesorderid = sh.salesorderid)
   WHERE sd.UnitPrice = @var
END

use AdventureWorks2017
go


Select * from sys.procedures

exec Proc_sales

Exec sp_helptext demo_withencryption
GO

CREATE OR ALTER PROCEDURE demo_withencryption
WITH ENCRYPTION
AS
  Select p.FirstName, p.LastName, p.NameStyle
  from Person.Person p
