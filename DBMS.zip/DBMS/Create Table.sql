	use Demo
	go

	CREATE TABLE dbo.student
	(
	  student_id int,
	  f_name nvarchar(20),
	  l_name nvarchar(20),
	  birth_date date,
	  course_id int
	)

	GO

