USE [Northwind]
GO

/****** Object:  Table [dbo].[Customers]    Script Date: 03/14/2011 13:21:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Customers]
(
	[CustomerID] [nchar](5) NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[City] [nvarchar](15) NULL
	
 )
 go
 
 CREATE NONCLUSTERED INDEX idx_Customers_Custid
    ON Customers ([CustomerID])
  go

	
	ALTER INDEX idx_Customers_Custid
	ON Customers REBUILD
	
	
ALTER INDEX idxnc_Customers_ContactName
ON Customers REORGANIZE


