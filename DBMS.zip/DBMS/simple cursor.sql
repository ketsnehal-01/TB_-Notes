use sample_query
GO

DECLARE @empid int,
        @name varchar(20),
		@job varchar(20),
		@deptid int
DECLARE cur_emp CURSOR
FOR
SELECT empno,ename,job, DEPTNO FROM emp
WHERE deptno = 20

OPEN cur_emp

FETCH NEXT FROM cur_emp INTO @empid,@name, @job, @deptid
   WHILE @@FETCH_STATUS = 0
   BEGIN
        SELECT @empid, @name, @job ,@deptid
		FETCH NEXT FROM cur_emp INTO @empid,@name, @job, @deptid
	END

CLOSE cur_emp
DEALLOCATE cur_emp
