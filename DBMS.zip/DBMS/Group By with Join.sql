Select * from sales.SalesOrderDetail
GO

Select * from sales.SalesOrderHeader
Go

SELECT soh.OrderDate, count(sod.productid) as 'ProductCount', sum(sod.unitprice) as 'Total_Price', 
sum(sod.OrderQty) as 'TotalQunatity'
FROM sales.SalesOrderDetail sod INNER JOIN Sales.SalesOrderHeader soh
ON (sod.SalesOrderID = soh.SalesOrderID)
GROUP BY soh.OrderDate
ORDER BY 1