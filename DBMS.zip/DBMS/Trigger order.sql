USE Sample_Query
GO


CREATE OR ALTER TRIGGER INCR_DEPCOUNT
ON dbo.emp
AFTER INSERT AS 
DECLARE
@cnt int,
@dname varchar(20)
BEGIN
  SET NOCOUNT ON;
  SELECT @cnt = count(e.deptno)
  FROM emp e
  WHERE e.deptno = (SELECT i.deptno FROM inserted i)

  SELECT @dname = DNAME
  FROM DEPT
  WHERE Deptno = (SELECT deptno FROM inserted)

  SELECT 'Departname :' + convert(varchar(20),@dname), 'Count of Employees :' +convert(varchar(20),@cnt)

END

  
INSERT INTO emp
VALUES (7700, 'Catherine' ,'Sales',1001,'12-Mar-1977',4530,NULL,30)

select * from emp_rec

EXEC sp_settriggerorder
@triggername='INCR_DEPCOUNT',
@ORDER = 'FIRST',
@stmttype = 'INSERT'