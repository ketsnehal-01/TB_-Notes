ALTER DATABASE DBtry SET READ_COMMITTED_SNAPSHOT ON
/* THIS SNAPSHOT DOES NOTPERMIT TO READ DATA WHEN AN INSERT IS DONE*/

ALTER DATABASE DBtry SET ALLOW_SNAPSHOT_ISOLATION ON

/* This snapshot read data even after insert is done by specifying isolation level 
as snapshot as in example below*/

begin tran
update employee
set title = 'program manager'
where title = 'cordinator'

COMMIT

SET Transaction ISOLATION LEVEL SNAPSHOT

begin tran
SELECT * FROM EMPLOYEE