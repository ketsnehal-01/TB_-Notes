USE AdventureWorks2017
GO

CREATE VIEW sales.salesdetails
AS
   SELECT sh.SalesOrderID,sd.ProductID, sd.UnitPrice, sd.OrderQty,
   sh.OrderDate
   FROM sales.salesorderdetail sd JOIN sales.salesorderheader sh
   ON (sd.SalesOrderID = sh.salesOrderID)

   SELECT * FROM Sales.salesdetails
   WHERE OrderQty > 10
   ORDER BY 3

   SELECT SalesOrderID,OrderDAte, count(*) as 'Count of Orders'
   , sum(OrderQty) AS 'Total Quantity',
   Sum(UNITPRICE) AS 'Total Price'
   FROM Sales.salesdetails
   GROUP BY SalesOrderID, OrderDate
   ORDER BY 1,2 