USE demo
GO
--SELECT * FROM Courses


BEGIN TRY
BEGIN TRAN
   INSERT INTO courses
   VALUES (3, 'Database','E-Learning',20)
   INSERT INTO courses
   VALUES (5,'Dynamics','Science',10)

Commit TRAN
END TRY

BEGIN CATCH

SELECT 'Error While Inserting'
ROLLBACK

END CATCH