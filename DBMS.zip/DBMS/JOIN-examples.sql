SELECT   P.FirstName,
         P.LastName,
         P.Title,
         PH.PhoneNumber
FROM     Person.Person AS P
         INNER JOIN
         Person.PersonPhone AS PH
         ON P.BusinessEntityID = PH.BusinessEntityID
         AND PH.PhoneNumberTypeID = 3
ORDER BY P.LastName

Select p.Title, p.FirstName, p.LastName, e.JobTitle, e.BirthDate, e.MaritalStatus, 
e.Gender,e.HireDate, e.VacationHours, pa.City, pa.PostalCode
FROM Person.Person p JOIN HumanResources.Employee e
ON (p.BusinessEntityID = e.BusinessEntityID)
JOIN Person.BusinessEntityAddress ba ON (ba.BusinessEntityID = p.BusinessEntityID)
JOIN Person.Address pa ON (pa.AddressID = ba.AddressID)
WHERE p.Title is NOT NULL OR e.VacationHours > 20
GO

