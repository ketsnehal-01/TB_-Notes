//Implementation of BFS Algo.

#include <iostream>
#include<vector>
#include<queue>
using namespace std;

void BFS(vector<vector<int>>& graph, int startNode){
    int numNodes = graph.size();
    vector<bool> visited(numNodes,false);
    queue<int> q;
    q.push(startNode);
    visited[startNode]=true;
    
    while(!q.empty()){
        int currNode = q.front();
        q.pop();
        cout<<currNode<<"  ";
        
        for(int neighbour:graph[currNode]){
            if(!visited[neighbour]){
                q.push(neighbour);
                visited[neighbour]=true;
            }
        }
    }
}

int main(){
    int numNodes,numEdges;
    cout<<"Enter the number of nodes";
    cin>>numNodes;
    
    cout<<"Enter the number of edges";
    cin>>numEdges;
    
    vector<vector<int>>graph(numNodes);
    
    cout<<"Enter the edges(u-->v)";
    
    for(int i=0;i<numEdges;i++){
        int u,v;
        cin>>u>>v;
        
        graph[u].push_back(v);
        graph[v].push_back(u);
        
        
    }
    
    int startNode;
    cout<<"Enter the startnode";
    cin>>startNode;
    
    BFS(graph,startNode);
}

