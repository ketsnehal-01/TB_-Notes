// Implementation of Singly Linked List

#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    
    Node(int value){
        data=value;
        next=nullptr;
    }
};

class LinkedList{
    private:
    Node* head;
    
    public:
    LinkedList(){
        head=nullptr;
    }
    
    void insertbeginning(int value){
        Node* newNode = new Node(value);
        
        if(head==nullptr){
            head=newNode;
        }
        else{
            Node* temp=head;
            while(temp->next!=nullptr){
                temp=temp->next;
            }
            temp->next=newNode;
        }
    }
    
    void insertposition(int value, int position){
        if(position<0){
            cout<<"Invalid Input"<<endl;
            return;
        }
        
        Node* newNode = new Node(value);
        
        if(position==0 || head==nullptr){
            newNode->next=head;
            head=newNode;
        }
        else{
            Node* temp=head;
            int count=0;
            
            while(temp!=nullptr && count<position-1){
                temp=temp->next;
                count++;
            }
            if(temp==nullptr){
                cout<<"Invalid"<<endl;
                return;
            }
            
            newNode->next=temp->next;
            temp->next=newNode;
        }
    }
    
    void insertend(int value){
        Node* newNode = new Node(value);
        
        if(head==nullptr){
         head=newNode;   
        }
        else{
            Node* temp = head;
            while(temp->next!=nullptr){
                temp=temp->next;
            }
            temp->next=newNode;
        }
    }
    
    
    void deletebeginning(){
        if(head==nullptr){
            cout<<"List is empty"<<endl;
            return;
        }
        
        Node* temp=head;
        head=head->next;
        delete temp;
    }
    
    void deleteend(){
        if(head==nullptr){
            cout<<"List is empty"<<endl;
            return;
        }
        
        if(head->next==nullptr){
            delete head;
            head=nullptr;
            return;
        }
        
        Node* prev = nullptr;
        Node* current = head;
        
        while(current->next!=nullptr){
            prev=current;
            current=current->next;
        }
        
        prev->next=nullptr;
        delete current;
    }
    
    void deleteposition(int position){
        if(position<0 || head==nullptr){
            cout<<"Invalid"<<endl;
            return;
        }
        
        if(position==0){
            Node* temp = head;
            head=head->next;
            delete temp;
            return;
        }
        
        Node* prev=nullptr;
        Node* current = head;
        int count=0;
        
        while(current!=nullptr && count<position){
            prev=current;
            current=current->next;
            count++;
        }
        
        if(current==nullptr){
            cout<<"Invalid"<<endl;
            return;
        }
        
        prev->next=current->next;
        delete current;
        
    }
    
    
    void display(){
        if(head==nullptr){
            cout<<"List is empty"<<endl;
            return;
        }
        
        Node* temp=head;
        
        while(temp!=nullptr){
            cout<<temp->data<<"  ";
            temp=temp->next;
        }
        cout<<endl;
    }

};

int main(){
    LinkedList obj;
    
    obj.insertbeginning(5);
    obj.insertposition(10,1);
    obj.insertend(20);
    obj.insertend(45);
    
    obj.display();
    
    obj.deletebeginning();
    obj.deleteposition(1);
    obj.deleteend();
    
    obj.display();
}






















