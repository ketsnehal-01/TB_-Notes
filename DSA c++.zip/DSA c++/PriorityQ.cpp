//priority queue implementation

#include <iostream>
using namespace std;

const int MAX_SIZE=100;

class PriorityQ{
    private:
    int arr[MAX_SIZE];
    int size;
    
    public:
    PriorityQ(){
        size=0;
    }
    
    bool isEmpty(){
        return (size==0);
    }
    
    bool isFull(){
        return (size==MAX_SIZE);
    }
    
    void enqueue(int value){
        if(isFull()){
            cout<<"Priority Q is Overflow"<<endl;
            return;
        }
        
        int i;
        for(i=size-1;i>=0;i--){
            if(value>arr[i]){
                arr[i+1]=arr[i];
            }
            else{
                break;
            }
        }
        arr[i+1]=value;
        size++;
    }
    
    
    int dequeue(){
        if(isEmpty()){
            cout<<"Priority Q is Underflow"<<endl;
            return -1;
        }
        
        int dequeddata=arr[size-1];
        size--;
        
        return dequeddata;
    }
    
    int peek(){
        if(isEmpty()){
            cout<<"Priority Q is Empty"<<endl;
            return -1;
        }
        
        return arr[size-1];
    }
};

int main()
{
 PriorityQ obj;
 obj.enqueue(12);
 obj.enqueue(56);
 obj.enqueue(23);
 obj.enqueue(4);
 obj.enqueue(9);
 obj.enqueue(7);
 
 cout<<"Peek Element="<<obj.peek()<<endl;
 cout<<"Dequeued data="<<obj.dequeue()<<endl;
 cout<<"Dequeued data="<<obj.dequeue()<<endl;
 cout<<"Peek Element="<<obj.peek()<<endl;
    
    
    return 0;
}