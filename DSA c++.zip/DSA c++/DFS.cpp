// Implementation of DFS Algo. 

#include<iostream>
#include<vector>
#include<stack>
using namespace std;


void DFS(vector<vector<int>> & graph, int startNode){
    int numNodes = graph.size();
    
    vector<bool> visited(numNodes,false);
    
    stack<int> stk;
    
    stk.push(startNode);
    visited[startNode]=true;
    
    while(!stk.empty()){
        int currNode=stk.top();
        stk.pop();
        cout<<currNode<<"  ";
        
        for(int neighbour:graph[currNode]){
            if(!visited[neighbour]){
                stk.push(neighbour);
                visited[neighbour]=true;
            }
        }
    }
}

int main(){
    int numNodes,numEdges;
    cout<<"Enter the number of nodes in the graph";
    cin>>numNodes;
    
    cout<<"Enter the number of edges in the graph";
    cin>>numEdges;
    
    vector<vector<int>>graph(numNodes);
    
    cout<<"Enter the edges (u->v)in the graph";
    for(int i=0;i<numEdges;i++){
        int u, v;
        cin>>u>>v;
        
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    
    int startNode;
    cout<<"Enter the startnode";
    cin>>startNode;
    
    DFS(graph,startNode);
}













