// Implementation of Reverse of Singly Linked List

#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    
    Node(int value){
        data=value;
        next=nullptr;
    }
};

class LinkedList{
    private:
    Node* head;
    
    public:
    LinkedList(){
        head=nullptr;
    }
    
    void insertbeginning(int value){
        Node* newNode = new Node(value);
       
       newNode->next=head;
       head=newNode;
       
    }
    
    void reverse(){
        Node* curr = head;
        Node* prev = nullptr;
        Node* next = nullptr;
        
        while(curr!=nullptr){
            next=curr->next;
            curr->next=prev;
            prev=curr;
            curr=next;
        }
        head=prev;
    }
    
    void display(){
    
    Node* temp = head;
    
        while(temp!=nullptr){
            cout<<temp->data<<"  ";
            temp=temp->next;
        }
        cout<<endl;
        
    }

};

int main(){
    LinkedList obj;
    
    obj.insertbeginning(5);
    obj.insertbeginning(10);
    obj.insertbeginning(15);
    obj.insertbeginning(20);
    obj.insertbeginning(25);
    
    cout<<"Original List"<<endl;
    obj.display();
    
    obj.reverse();
    
    cout<<"Reverse List"<<endl;
    obj.display();
}



