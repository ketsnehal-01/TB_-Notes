// linear search algo...


#include<iostream>
using namespace std;


int linearsearch(int arr[], int size, int target){
    for(int i=0;i<size;i++){
        if(arr[i]==target){
            return i;
        }
    }
    
    return -1;  //not found
}

int main(){
    int arr[]={9,2,5,7,1,8,4,3,6};
    int size = sizeof(arr)/sizeof(arr[0]);
    int target=10;
    
    int index = linearsearch(arr,size,target);
    
    if(index!=-1){
        cout<<"Element found at index"<<index<<endl;
    }
    else{
        cout<<"Element not found";
    }
    
    
}