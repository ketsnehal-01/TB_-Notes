//Selection Sort

#include <iostream>
using namespace std;

void selectionsort(int arr[],int size){
    for(int i=0;i<size-1;i++){
        int minIndex = i;
        
        for(int j = i+1;j<size;j++){
            if(arr[j]<arr[minIndex]){
                minIndex=j;
            }
        }
        int temp = arr[i];
        arr[i]=arr[minIndex];
        arr[minIndex]=temp;
    }
}

void display(int arr[],int size){
    for(int i=0;i<size;i++){
        cout<<arr[i]<<"  ";
    }
    cout<<endl;
}

int main()
{
    
    int arr[] = {20,12,10,15,2};
    int size = sizeof(arr)/sizeof(arr[0]);
    cout<<"Before Sorting"<<endl;
    display(arr,size);
    selectionsort(arr,size);
    cout<<"After Sorting"<<endl;
    display(arr,size);
    return 0;
}












