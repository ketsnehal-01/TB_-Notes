//Double Ended queue (Deque) implementation

#include <iostream>
using namespace std;

const int MAX_SIZE=100;

class Deque{
    private:
    int arr[MAX_SIZE];
    int front;
    int rear;
    
    public:
    Deque(){
        front=-1;
        rear=-1;
    }
    
    bool isEmpty(){
        return (front==-1);
    }
    
    bool isFull(){
        
        return ((front==0 && rear==MAX_SIZE-1) || front==rear+1);
    }

    void insertfront(int value){
        if(isFull()){
            cout<<"Overflow"<<endl;
            return;
        }
        
        if(isEmpty()){
            front=0;
            rear=0;
        }
        else if(front==0){
            front=MAX_SIZE-1;
        }
        else{
        front--;
        }
        arr[front]=value;
    }
    
    void insertrear(int value){
        if(isFull()){
            cout<<"Overflow"<<endl;
            return;
        }
        
        if(isEmpty()){
            front=0;
            rear=0;
        }
        else if(rear==MAX_SIZE-1){
            rear=0;
        }
        else{
            rear++;
        }
        arr[rear]=value;
    }
    
    int deletefront(){
        if(isEmpty()){
            cout<<"Underflow"<<endl;
            return -1;
        }
        
        int x = arr[front];
        
        if(front==rear){
            front=-1;
            rear=-1;
        }
        else if(front==MAX_SIZE-1){
            front=0;
        }
        else{
            front++;
        }
        
        return x;
    }
    
    int deleterear(){
        if(isEmpty()){
            cout<<"Underflow"<<endl;
            return -1;
        }
        
        int x = arr[rear];
        
        if(front==rear){
            front=-1;
            rear=-1;
        }
        else if(rear==0){
            rear=MAX_SIZE-1;
        }
        else{
            rear--;
        }
        return x;
    }
    
    int peekfront(){
        if(isEmpty()){
            cout<<"DQ is Empty"<<endl;
            return -1;
        }
        return arr[front];
    }
    
    int peekrear(){
        if(isEmpty()){
            cout<<"DQ is Empty"<<endl;
            return -1;
        }
        return arr[rear];
    }

};

int main(){
    Deque obj;
    obj.insertfront(10);
    obj.insertfront(20);
    obj.insertrear(100);
    obj.insertrear(200);
    
    cout<<"Front Element="<<obj.peekfront()<<endl;
    cout<<"Rear Element="<<obj.peekrear()<<endl;
    
    cout<<"Deleted from Front Side="<<obj.deletefront()<<endl;
    cout<<"Deleted from Rear Side="<<obj.deleterear()<<endl;

    cout<<"Front Element="<<obj.peekfront()<<endl;
    cout<<"Rear Element="<<obj.peekrear()<<endl;
    }












