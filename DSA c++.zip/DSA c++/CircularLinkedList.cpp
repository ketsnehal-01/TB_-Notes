// Implementation of Circular Linked List

#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    
    Node(int value){
        data=value;
        next=nullptr;
    }
};

class CircularLinkedList{
    private:
    Node* head;
    
    public:
    CircularLinkedList(){
        head=nullptr;
    }
    
    void insertbeginning(int value){
        Node* newNode = new Node(value);
        
        if(head==nullptr){
            head=newNode;
            newNode->next=head;
        }
        else{
            Node* temp=head;
            while(temp->next!=head){
                temp=temp->next;
            }
            newNode->next=head;
            temp->next=newNode;
            head=newNode;
        }
    }
    
    void insertposition(int value, int position){
        if(position<0){
            cout<<"Invalid Input"<<endl;
            return;
        }
        
        if(position==0 || head==nullptr){
            insertbeginning(value);
            return;
        }
        
        Node* newNode = new Node(value);
        Node* temp=head;
        int count=0;
        
        while(temp->next!=head && count<position-1){
                temp=temp->next;
                count++;
            }
            if(count<position-1){
                cout<<"Invalid"<<endl;
                return;
            }
            
            newNode->next=temp->next;
            temp->next=newNode;
        }
    
    
    void insertend(int value){
        Node* newNode = new Node(value);
        
        if(head==nullptr){
         head=newNode; 
         newNode->next=head;
        }
        else{
            Node* temp = head;
            while(temp->next!=head){
                temp=temp->next;
            }
            temp->next=newNode;
            newNode->next=head;
        }
    }
    
    
    void deletebeginning(){
        if(head==nullptr){
            cout<<"List is empty"<<endl;
            return;
        }
        
        if(head->next==head){
            delete head;
            head=nullptr;
            return;
        }
        
        Node* temp=head;
        while(temp->next!=head){
            temp=temp->next;
        }
        temp->next=head->next;
        delete head;
        head=temp->next;
        
    }
    
    void deleteend(){
        if(head==nullptr){
            cout<<"List is empty"<<endl;
            return;
        }
        
        if(head->next==head){
            delete head;
            head=nullptr;
            return;
        }
        
        Node* temp = head;
        
        
        while(temp->next->next!=head){
            temp=temp->next;
        }
        
        delete temp->next;
        temp->next=head;
    }
    
    void deleteposition(int position){
        if(position<0 || head==nullptr){
            cout<<"Invalid"<<endl;
            return;
        }
        
        if(position==0){
            deletebeginning();
            return;
        }
        
        Node* temp=head;
        int count=0;
        
        while(temp->next!=head && count<position-1){
        
            temp=temp->next;
            count++;
        }
        
        if(count<position-1){
            cout<<"Invalid"<<endl;
            return;
        }
        
        Node* nodetodelete = temp->next;
        temp->next=nodetodelete->next;
        delete nodetodelete;
    }
    
    
    void display(){
        if(head==nullptr){
            cout<<"List is empty"<<endl;
            return;
        }
        
        Node* temp=head;
        
        do{
            cout<<temp->data<<"  ";
            temp=temp->next;
        }while(temp!=head);
        
        cout<<endl;
    }

};

int main(){
    CircularLinkedList obj;
    
    obj.insertbeginning(5);
    obj.insertposition(10,1);
    obj.insertend(20);
    obj.insertend(45);
    
    obj.display();
    
    obj.deletebeginning();
    obj.deleteposition(1);
    obj.deleteend();
    
    obj.display();
}



