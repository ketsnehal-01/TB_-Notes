#include<iostream>
using namespace std;

const int MAX_SIZE=100;

class Stack{
	private:
		int arr[MAX_SIZE];
		int top;
		
	public:
		Stack(){
			top=-1;
		}
		
	bool isEmpty(){
		return (top==-1);
	}
	
	bool isFull(){
		return (top==MAX_SIZE-1);
	}
	
	void push(int value){
		if(isFull()){
			cout<<"Stack is OVERFLOW"<<endl;
			return;
		}
		arr[++top]=value;
	}
	
	int pop(){
		if(isEmpty()){
			cout<<"Stack is UNDERFLOW"<<endl;
			return -1;
		}
		
		return arr[top--];
	}
	
	int peek(){
		if(isEmpty()){
			cout<<"Stack is Empty"<<endl;
			return -1;
		}
		
		return arr[top];
	}
};

int main(){
	Stack obj;
	obj.push(100);
	obj.push(200);
	obj.push(300);
	obj.push(400);
	obj.push(500);
	
	cout<<"Top Element is="<<obj.peek()<<endl;
	cout<<"Popped Element is = "<<obj.pop()<<endl;
	cout<<"Popped Element is = "<<obj.pop()<<endl;
	cout<<"Top Element is="<<obj.peek()<<endl;

	cout<<"Popped Element is = "<<obj.pop()<<endl;
	cout<<"Popped Element is = "<<obj.pop()<<endl;
	cout<<"Popped Element is = "<<obj.pop()<<endl;
	cout<<"Popped Element is = "<<obj.pop()<<endl;	
}

















