// Tree Traversals Implementation

#include<iostream>
using namespace std;

struct TreeNode{
    int data;
    TreeNode* left;
    TreeNode* right;
    
    TreeNode(int val): data(val),left(nullptr),right(nullptr){}
};

//inorder 

void inorder(TreeNode* root){
    if(root==nullptr){
        return;
    }
    
    inorder(root->left);
    cout<<root->data<<"  ";
    inorder(root->right);
}

//postorder

void postorder(TreeNode* root){
    if(root==nullptr){
        return;
    }
    
    postorder(root->left);
    postorder(root->right);
    cout<<root->data<<"  ";
    
}

//preorder

void preorder(TreeNode* root){
    if(root==nullptr){
        return;
    }
    
    cout<<root->data<<"  ";
    postorder(root->left);
    postorder(root->right);
    
}

int main(){
    TreeNode* root = new TreeNode(1);
    root->left=new TreeNode(2);
    root->right=new TreeNode(3);
    root->left->left=new TreeNode(4);
    root->left->right=new TreeNode(5);
    root->right->left=new TreeNode(6);
    root->right->right=new TreeNode(7);
    
    cout<<"Inorder Traversal "<<endl;
    inorder(root);
    cout<<endl;
    
    cout<<"Preorder Traversal "<<endl;
    preorder(root);
    cout<<endl;
    
    cout<<"Postorder Traversal "<<endl;
    postorder(root);
    cout<<endl;
}


























