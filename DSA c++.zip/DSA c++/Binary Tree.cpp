//Binary Tree with all operations


#include <iostream>
#include <queue>
using namespace std;

// Tree node structure
struct TreeNode {
    int data;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : data(val), left(nullptr), right(nullptr) {}
};

// Function to insert a node into the binary tree
TreeNode* insertNode(TreeNode* root, int val) {
    if (root == nullptr) {
        return new TreeNode(val);
    }

    queue<TreeNode*> q;
    q.push(root);

    while (!q.empty()) {
        TreeNode* current = q.front();
        q.pop();

        if (current->left == nullptr) {
            current->left = new TreeNode(val);
            break;
        } else {
            q.push(current->left);
        }

        if (current->right == nullptr) {
            current->right = new TreeNode(val);
            break;
        } else {
            q.push(current->right);
        }
    }

    return root;
}

// Function to delete a node from the binary tree
TreeNode* deleteNode(TreeNode* root, int val) {
    if (root == nullptr) {
        return root;
    }

    if (root->left == nullptr && root->right == nullptr) {
        if (root->data == val) {
            delete root;
            return nullptr;
        } else {
            return root;
        }
    }

    queue<TreeNode*> q;
    q.push(root);

    TreeNode* targetNode = nullptr;
    TreeNode* deepestNode = nullptr;

    while (!q.empty()) {
        TreeNode* current = q.front();
        q.pop();

        if (current->data == val) {
            targetNode = current;
        }

        if (current->left != nullptr) {
            q.push(current->left);
            deepestNode = current->left;
        }

        if (current->right != nullptr) {
            q.push(current->right);
            deepestNode = current->right;
        }
    }

    if (targetNode != nullptr) {
        targetNode->data = deepestNode->data;
        delete deepestNode;
    }

    q.push(root);

    while (!q.empty()) {
        TreeNode* current = q.front();
        q.pop();

        if (current->left != nullptr) {
            if (current->left == deepestNode) {
                current->left = nullptr;
                break;
            } else {
                q.push(current->left);
            }
        }

        if (current->right != nullptr) {
            if (current->right == deepestNode) {
                current->right = nullptr;
                break;
            } else {
                q.push(current->right);
            }
        }
    }

    return root;
}

// Function to search for a node in the binary tree
bool searchNode(TreeNode* root, int val) {
    if (root == nullptr) {
        return false;
    }

    if (root->data == val) {
        return true;
    }

    return searchNode(root->left, val) || searchNode(root->right, val);
}

// Function to perform inorder traversal of the binary tree
void inorderTraversal(TreeNode* root) {
    if (root == nullptr) {
        return;
    }

    inorderTraversal(root->left);
    cout << root->data << " ";
    inorderTraversal(root->right);
}

// Function to calculate the height of the binary tree
int calculateHeight(TreeNode* root) {
    if (root == nullptr) {
        return 0;
    }

    int leftHeight = calculateHeight(root->left);
    int rightHeight = calculateHeight(root->right

);

    return max(leftHeight, rightHeight) + 1;
}

int main() {
    // Create the binary tree
    TreeNode* root = nullptr;
    root = insertNode(root, 4);
    insertNode(root, 2);
    insertNode(root, 1);
    insertNode(root, 3);
    insertNode(root, 6);
    insertNode(root, 5);

    // Perform inorder traversal
    cout << "Inorder traversal: ";
    inorderTraversal(root);
    cout << endl;

    // Delete a node from the binary tree
    root = deleteNode(root, 3);

    // Perform inorder traversal after deletion
    cout << "Inorder traversal after deletion: ";
    inorderTraversal(root);
    cout << endl;

    // Search for a node in the binary tree
    int searchVal = 5;
    bool found = searchNode(root, searchVal);
    cout << "Node " << searchVal << " found: " << (found ? "true" : "false") << endl;

    // Calculate the height of the binary tree
    int height = calculateHeight(root);
    cout << "Height of the binary tree: " << height << endl;

    return 0;
}