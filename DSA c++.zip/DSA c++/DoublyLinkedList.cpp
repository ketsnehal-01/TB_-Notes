// Implementation of Doubly Linked List

#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    Node* prev;
    
    Node(int value){
        data=value;
        next=nullptr;
        prev=nullptr;
    }
};

class DoublyLinkedList{
    
    private:
    Node* head;
    
    public:
    DoublyLinkedList(){
        head=nullptr;
    }
    
    void insertbegin(int value){
        Node* newNode = new Node(value);
        
        if(head==nullptr){
            head=newNode;
        }
        else{
            newNode->next=head;
            head->prev=newNode;
            head=newNode;
        }
    }
    
    void insertend(int value){
        Node* newNode = new Node(value);
        
        if(head==nullptr){
            head=newNode;
        }
        else{
            
            Node* temp = head;
            
            while(temp->next != nullptr){
                temp=temp->next;
            }
            temp->next=newNode;
            newNode->prev = temp;
        }
    }



    void insertposition(int value, int position){
        if(position<0){
            cout<<"Invalid"<<endl;
            return;
        }
        
        Node* newNode = new Node(value);
        
        if(position==0 || head==nullptr){
            newNode->next=head;
            
            if(head!=nullptr){
                head->prev=newNode;
            }
            head=newNode;
        }else{
            Node* temp = head;
            int count=0;
            
            while(temp!=nullptr && count<position-1){
                temp=temp->next;
                count++;
            }
            
            if(temp==nullptr){
                cout<<"Invalid "<<endl;
                return;
            }
            
            newNode->next=temp->next;
            if(temp->next!=nullptr){
                temp->next->prev=newNode;
            }
            
            temp->next=newNode;
            newNode->prev=temp;
        }
    }
    
    void deletebegin(){
        if(head==nullptr){
            cout<<"List is empty"<<endl;
            return;
        }
        
        Node* temp=head;
        head=head->next;
        
        if(head!=nullptr){
            head->prev=nullptr;
        }
        delete temp;
    }
    
    void deleteend(){
        if(head==nullptr){
            cout<<"List is Empty"<<endl;
            return;
        }
        
        if(head->next==nullptr){
            delete head;
            head=nullptr;
            return;
        }
        
        Node* temp = head;
        
        while(temp->next!=nullptr){
            temp=temp->next;
        }
        temp->prev->next=nullptr;
        delete temp;
        
    }
    
    void deleteposition(int position){
        if(position<0 || head==nullptr){
            cout<<"Invalid"<<endl;
            return;
        }
        
        if(position==0){
            Node* temp=head;
            head=head->next;
            if(head!=nullptr){
                head->prev=nullptr;
            }
            delete temp;
            return;
        }
        
        Node* temp=head;
        int count=0;
        
        while(temp!=nullptr && count<position){
            temp=temp->next;
            count++;
        }
        
        if(temp==nullptr){
            cout<<"Invalid"<<endl;
            return;
        }
        
        
        temp->prev->next=temp->next;
        if(temp->next!=nullptr){
            temp->next->prev = temp->prev;
        }
        delete temp;
        
    }
    
    void display(){
        if(head==nullptr){
            cout<<"List is Empty"<<endl;
            return;
        }
        
        Node* temp =head;
        
        while(temp!=nullptr){
            cout<<temp->data<<"  ";
            temp=temp->next;
        }
        cout<<endl;
    }
};

int main(){
    DoublyLinkedList obj;
    
    obj.insertend(10);
    obj.insertend(20);
    obj.insertbegin(5);
    obj.insertposition(15,2);
    
    obj.display();
    
    obj.deleteend();
    obj.deletebegin();
    obj.deleteposition(1);
    
    obj.display();
}





















