// Binary Search Tree Implementation

#include<iostream>
using namespace std;

struct TreeNode{
    int data;
    TreeNode* left;
    TreeNode* right;
    
    TreeNode(int val):data(val),left(nullptr),right(nullptr){}
};

TreeNode* insertNode(TreeNode* root, int val){
    if(root==nullptr){
        return new TreeNode(val);
    }
    
    if(val<root->data){
        root->left=insertNode(root->left,val);
    }
    else{
        root->right=insertNode(root->right,val);
    }
    
    return root;
}

bool searchNode(TreeNode* root, int val){
    if(root==nullptr){
        return false;
    }
    
    if(root->data==val){
        return true;
    }
    else if(val<root->data){
        return searchNode(root->left,val);
    }
    else{
        return searchNode(root->right,val);
    }
}

int findMin(TreeNode* root){
    if(root->left==nullptr){
        return root->data;
    }
    return findMin(root->left);
}

int findMax(TreeNode* root){
    if(root->right==nullptr){
        return root->data;
    }
    return findMax(root->right);
}

TreeNode* deleteNode(TreeNode* root, int val){
    if(root==nullptr){
        return root;
    }
    
    if(val<root->data){
        root->left = deleteNode(root->left,val);
    }
    else if(val>root->data){
        root->right = deleteNode(root->right,val);
    }
    else{
        
        if(root->left == nullptr && root->right == nullptr){  //case 1
            delete root;
            root=nullptr;
        }
        
        else if(root->left==nullptr){   //case 2
            TreeNode* temp=root;
            root=root->right;
            delete temp;
        }
        else if(root->right==nullptr){
            TreeNode* temp = root;
            root=root->left;
            delete temp;
        }
        
        else{    //case 3
            int minValue = findMin(root->right);
            root->data=minValue;
            root->right=deleteNode(root->right,minValue);
        }
    }

        return root;
    
}

void inorder(TreeNode* root){
    if(root==nullptr){
        return;
    }
    
    inorder(root->left);
    cout<<root->data<<"  ";
    inorder(root->right);
    
}

//driver code

int main(){
    TreeNode* root = nullptr;
    root=insertNode(root,4);
    insertNode(root,2);
    insertNode(root,1);
    insertNode(root,3);
    insertNode(root,6);
    insertNode(root,5);
    
    cout<<"Inorder Traversal ="<<endl;
    inorder(root);
    cout<<endl;
    
    int key = 5;
    bool found = searchNode(root,key);
    
    cout<<"Node" <<key<< "FOUND"<<(found?"true":"false")<<endl;
    
    int min = findMin(root);
    int max = findMax(root);
    
    cout<<"Minimum Value ="<<min<<endl;
    cout<<"Maximum Value ="<<max<<endl;
    
    root = deleteNode(root, 3);
    
    cout<<"After Deletion"<<endl;
    inorder(root);
}










