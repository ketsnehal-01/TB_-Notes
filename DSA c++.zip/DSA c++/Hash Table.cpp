// Hashing Implementation

#include<iostream>
using namespace std;

const int TABLE_SIZE=10;

struct Node{
    int key;
    int value;
    Node* next;
    
    Node(int key,int value):key(key),value(value),next(nullptr){}
    
};

class HashTable{
    private:
    Node** table;
    
    int hashfunction(int key){
        return key%TABLE_SIZE;
    }
    
    public:
    HashTable(){
        table = new Node*[TABLE_SIZE];
        for(int i=0;i<TABLE_SIZE;i++){
            table[i]=nullptr;
        }
    }
    
    ~HashTable(){
        for(int i=0;i<TABLE_SIZE;i++){
        Node* current = table[i];
        while(current){
            Node* temp = current;
            current=current->next;
            delete temp;
        }
    }
    delete[] table;
}

void insert(int key,int value){
    int hashvalue = hashfunction(key);
    Node* newNode = new Node(key,value);
    
    if(table[hashvalue]==nullptr){  //no collision
        table[hashvalue]=newNode;
    }
    else{   //collision
        Node* current = table[hashvalue];
        while(current->next){
            current=current->next;
        }
        current->next=newNode;
    }
}

int search(int key){
    int hashvalue = hashfunction(key);
    
    Node* current = table[hashvalue];
    
    while(current){
        if(current->key==key){
            return current->value;
        }
        current=current->next;
    }
    return -1;
}

void remove(int key){
    int hashvalue = hashfunction(key);
    Node* current = table[hashvalue];
    Node* prev = nullptr;
    
    while(current){
        if(current->key==key){
            if(prev==nullptr){
                table[hashvalue]=current->next;
            }
            else{
                prev->next=current->next;
            }
            delete current;
            return;
        }
        prev=current;
        current=current->next;
    }
}
};

int main(){
    HashTable obj;
    obj.insert(1,100);
    obj.insert(2,200);
    obj.insert(3,300);
    obj.insert(4,400);
    obj.insert(5,500);
    
    obj.remove(2);
    int value = obj.search(2);
    
    if(value!=-1){
        cout<<"Value found"<<endl;
    }
    else{
        cout<<"Not Found"<<endl;
    }
    
    
    
    
}





