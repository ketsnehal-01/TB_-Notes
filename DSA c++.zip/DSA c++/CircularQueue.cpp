//Circular Queue Implementation 


#include<iostream>
using namespace std;

const int MAX_SIZE=5;

class CircularQ{
    private:
    int arr[MAX_SIZE];
    int front;
    int rear;
    
    public:
    CircularQ(){
        front=-1;
        rear=-1;
    }
    
    bool isEmpty(){
        return (front==-1 && rear==-1);
    }
    
    bool isFull(){
        if(front==0 && rear==MAX_SIZE-1)
            return true;
        if(front==rear+1)
            return true;
        return false;
    }
    
    void enqueue(int value){
        if(isFull()){
            cout<<"Queue Overflow"<<endl;
            return ;
        }
        
        if(isEmpty()){
            front=0;
            rear=0;
        }
        else if(rear==MAX_SIZE-1){
            rear=0;
        }
        else{
            rear++;
        }
        arr[rear]=value;
    }
    
    int dequeue(){
        if(isEmpty()){
            cout<<"Queue Undeflow"<<endl;
            return -1;
        }
        
        int data=arr[front];
        
        if(front==rear){
            front=-1;
            rear=-1;
        }
        else if(front==MAX_SIZE-1){
            front=0;
        }
        else{
            front++;
        }
        
        return data;
    }
    
    int peek(){
        if(isEmpty()){
            cout<<"Queue is empty"<<endl;
            return -1;
        }
        
        return arr[front];
    }
};

int main(){
    CircularQ obj;
    obj.enqueue(15);
    obj.enqueue(20);
    obj.enqueue(25);
    obj.enqueue(30);
    obj.enqueue(35);
    
    cout<<"Front Element="<<obj.peek()<<endl;
    cout<<"Dequeued Element ="<<obj.dequeue()<<endl;
    cout<<"Dequeued Element ="<<obj.dequeue()<<endl;
    cout<<"Dequeued Element ="<<obj.dequeue()<<endl;
    cout<<"Front Element="<<obj.peek()<<endl;
    
    obj.enqueue(100);
    obj.enqueue(200);
    cout<<"Dequeued Element ="<<obj.dequeue()<<endl;
    cout<<"Dequeued Element ="<<obj.dequeue()<<endl;
    cout<<"Dequeued Element ="<<obj.dequeue()<<endl;
    cout<<"Front Element="<<obj.peek()<<endl;
    
}









